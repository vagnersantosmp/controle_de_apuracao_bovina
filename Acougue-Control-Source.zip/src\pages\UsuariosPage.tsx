import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Pencil, Search, Loader2, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

type AppRole = 'admin' | 'loja' | 'gestor' | 'prevencao';

interface UserRow {
  id: string;
  user_id: string;
  nome: string;
  email: string;
  loja_id: string | null;
  ativo: boolean;
  role?: AppRole;
  loja_nome?: string;
}

interface LojaOption {
  id: string;
  nome: string;
}

const roleLabels: Record<AppRole, string> = {
  admin: 'Administrador',
  loja: 'Loja',
  gestor: 'Gestor',
  prevencao: 'Prevenção',
};

export default function UsuariosPage() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [lojas, setLojas] = useState<LojaOption[]>([]);
  const [busca, setBusca] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);

  // Form state
  const [formNome, setFormNome] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formPerfil, setFormPerfil] = useState<AppRole>('loja');
  const [formLojaId, setFormLojaId] = useState('');

  const fetchUsers = async () => {
    setLoading(true);
    // Fetch profiles
    const { data: profiles } = await supabase.from('profiles').select('*');
    // Fetch roles
    const { data: roles } = await supabase.from('user_roles').select('*');
    // Fetch lojas
    const { data: lojasData } = await supabase.from('lojas').select('id, nome').eq('ativa', true);

    setLojas(lojasData || []);

    const rolesMap = new Map<string, AppRole>();
    (roles || []).forEach((r: any) => rolesMap.set(r.user_id, r.role));

    const lojasMap = new Map<string, string>();
    (lojasData || []).forEach((l: any) => lojasMap.set(l.id, l.nome));

    const mapped: UserRow[] = (profiles || []).map((p: any) => ({
      id: p.id,
      user_id: p.user_id,
      nome: p.nome,
      email: p.email,
      loja_id: p.loja_id,
      ativo: p.ativo,
      role: rolesMap.get(p.user_id) || 'loja',
      loja_nome: p.loja_id ? lojasMap.get(p.loja_id) || '—' : '—',
    }));

    setUsers(mapped);
    setLoading(false);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const resetForm = () => {
    setFormNome('');
    setFormEmail('');
    setFormPassword('');
    setFormPerfil('loja');
    setFormLojaId('');
    setEditId(null);
  };

  const handleEdit = (u: UserRow) => {
    setEditId(u.user_id);
    setFormNome(u.nome);
    setFormEmail(u.email);
    setFormPerfil(u.role || 'loja');
    setFormLojaId(u.loja_id || '');
    setFormPassword(''); // a senha não é mostrada por segurança, e se voltar vazia não altera
    setShowForm(true);
  };

  const toggleAtiva = async (u: UserRow) => {
    const { error } = await supabase.from('profiles').update({ ativo: !u.ativo }).eq('id', u.id);
    if (error) { toast.error(error.message); return; }
    toast.success(u.ativo ? 'Usuário inativado' : 'Usuário ativado');
    fetchUsers();
  };

  const handleDelete = async (u: UserRow) => {
    if (!confirm(`Tem certeza que deseja excluir o usuário ${u.nome}? Essa ação excluirá seu perfil do painel.`)) return;
    
    // Removing profile and role associations (Auth unbinding must be fully managed safely if required later)
    await supabase.from('user_roles').delete().eq('user_id', u.user_id);
    const { error } = await supabase.from('profiles').delete().eq('user_id', u.user_id);
    
    if (error) { toast.error('Erro ao excluir usuário: ' + error.message); return; }
    toast.success('Usuário removido da listagem.');
    fetchUsers();
  };

  const handleSave = async () => {
    if (!formNome || !formEmail || !formPassword) {
      toast.error('Preencha nome, e-mail e senha.');
      return;
    }
    if (formPerfil === 'loja' && !formLojaId) {
      toast.error('Selecione a loja vinculada.');
      return;
    }

    setSaving(true);
    
    if (editId) {
      // Editar usuário existente
      if (formPassword && formPassword.length < 6) {
        toast.error('A senha deve ter no mínimo 6 caracteres.');
        setSaving(false); return;
      }

      const { error: profileError } = await supabase.from('profiles').update({
        nome: formNome,
        loja_id: formPerfil === 'loja' ? formLojaId : null
      }).eq('user_id', editId);

      if (profileError) { toast.error('Erro ao atualizar perfil.'); setSaving(false); return; }

      // Invoke Edge function to update Auth credentials if provided
      if (formEmail || formPassword) {
        const { error: authUpdateError } = await supabase.functions.invoke('update-user', {
          body: {
            user_id: editId,
            ...(formEmail ? { email: formEmail } : {}),
            ...(formPassword ? { password: formPassword } : {}),
          }
        });
        
        if (authUpdateError) {
           let erroMsg = authUpdateError.message;
           try {
             const ctx = await authUpdateError.context?.json();
             if (ctx?.error) erroMsg = ctx.error;
           } catch(e) {}
           toast.error('Erro ao alterar credenciais: ' + erroMsg);
           setSaving(false); return;
        }
      }

      // atualiza role (usamos upsert ou update com cuidado dependendo da chave)
      await supabase.from('user_roles').upsert({ user_id: editId, role: formPerfil });

      setSaving(false);
      toast.success('Usuário atualizado com sucesso!');
      
    } else {
      // Criar novo usuário
      if (!formPassword) {
        toast.error('Preencha a senha para novos usuários.');
        setSaving(false); return;
      }
      
      const { data, error } = await supabase.functions.invoke('create-user', {
        body: {
          nome: formNome,
          email: formEmail,
          password: formPassword,
          perfil: formPerfil,
          loja_id: formPerfil === 'loja' ? formLojaId : null,
        },
      });

      setSaving(false);

      if (error || data?.error) {
        let erroMsg = data?.error || error?.message || 'Erro ao criar usuário';
        try {
          const ctx = await error?.context?.json();
          if (ctx?.error) erroMsg = ctx.error;
        } catch(e) {}
        toast.error(erroMsg);
        return;
      }

      toast.success('Usuário cadastrado com sucesso!');
    }

    setShowForm(false);
    resetForm();
    fetchUsers();
  };

  const filtered = users.filter(
    u => u.nome.toLowerCase().includes(busca.toLowerCase()) || u.email.toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="page-header flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="page-title">Gestão de Usuários</h1>
          <p className="page-description">{users.length} usuários cadastrados</p>
        </div>
        <Button onClick={() => { setShowForm(!showForm); if (!showForm) resetForm(); }}>
          <Plus className="h-4 w-4 mr-2" />Novo Usuário
        </Button>
      </div>

      {showForm && (
        <div className="bg-card rounded-lg border p-6">
          <h2 className="text-sm font-semibold mb-4">Cadastrar Novo Usuário</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <Label>Nome</Label>
              <Input placeholder="Nome completo" className="mt-1.5" value={formNome} onChange={e => setFormNome(e.target.value)} />
            </div>
            <div>
              <Label>E-mail</Label>
              <Input type="email" placeholder="email@rede.com.br" className="mt-1.5" value={formEmail} onChange={e => setFormEmail(e.target.value)} />
            </div>
            <div>
              <Label>{editId ? 'Nova Senha (opcional)' : 'Senha'}</Label>
              <Input type="password" placeholder="Mínimo 6 caracteres" className="mt-1.5" value={formPassword} onChange={e => setFormPassword(e.target.value)} />
            </div>
            <div>
              <Label>Perfil</Label>
              <select value={formPerfil} onChange={e => setFormPerfil(e.target.value as AppRole)} className="mt-1.5 w-full h-10 px-3 rounded-md border bg-background text-sm">
                <option value="admin">Administrador</option>
                <option value="loja">Loja</option>
                <option value="gestor">Gestor</option>
                <option value="prevencao">Prevenção</option>
              </select>
            </div>
            {formPerfil === 'loja' && (
              <div>
                <Label>Loja vinculada *</Label>
                <select value={formLojaId} onChange={e => setFormLojaId(e.target.value)} className="mt-1.5 w-full h-10 px-3 rounded-md border bg-background text-sm">
                  <option value="">Selecione</option>
                  {lojas.map(l => <option key={l.id} value={l.id}>{l.nome}</option>)}
                </select>
              </div>
            )}
          </div>
          <div className="flex gap-2 mt-4">
            <Button onClick={handleSave} disabled={saving}>
              {saving && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
              {saving ? 'Salvando...' : 'Salvar'}
            </Button>
            <Button variant="outline" onClick={() => { setShowForm(false); resetForm(); }}>Cancelar</Button>
          </div>
        </div>
      )}

      <div className="bg-card rounded-lg border p-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar usuário..." value={busca} onChange={e => setBusca(e.target.value)} className="pl-9" />
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      ) : (
        <div className="bg-card rounded-lg border overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="text-left p-3 font-medium text-muted-foreground">Nome</th>
                <th className="text-left p-3 font-medium text-muted-foreground">E-mail</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Perfil</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Loja</th>
                <th className="text-center p-3 font-medium text-muted-foreground">Status</th>
                <th className="text-center p-3 font-medium text-muted-foreground">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={6} className="p-8 text-center text-muted-foreground">Nenhum usuário encontrado</td></tr>
              ) : (
                filtered.map(u => (
                  <tr key={u.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                    <td className="p-3 font-medium">{u.nome}</td>
                    <td className="p-3">{u.email}</td>
                    <td className="p-3">{roleLabels[u.role || 'loja']}</td>
                    <td className="p-3">{u.loja_nome}</td>
                    <td className="p-3 text-center">
                      <button onClick={() => toggleAtiva(u)}>
                        <span className={cn('px-2.5 py-0.5 rounded-full text-xs font-medium border cursor-pointer hover:opacity-80', u.ativo ? 'bg-success/15 text-success border-success/30' : 'bg-muted text-muted-foreground')}>
                          {u.ativo ? 'Ativo' : 'Inativo'}
                        </span>
                      </button>
                    </td>
                    <td className="p-3 text-center">
                      <div className="flex justify-center gap-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={() => handleEdit(u)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive/70 hover:text-destructive hover:bg-destructive/10" onClick={() => handleDelete(u)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
