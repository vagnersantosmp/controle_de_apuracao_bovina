import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { StatusBadge } from '@/components/StatusBadge';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Eye, Copy, Search, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

interface LojaOption { id: string; nome: string; }

interface ApuracaoRow {
  id: string;
  data_apuracao: string;
  loja_id: string;
  tipo_apuracao: string;
  peso_carcaca: number;
  total_peso_inicial: number;
  total_peso_final: number;
  total_perda_kg: number;
  media_perda_percentual: number;
  status: 'rascunho' | 'finalizada' | 'revisada';
  responsavel: string;
  sif: string | null;
  numero_apuracao: string | null;
  loja_nome?: string;
}

export default function HistoricoPage() {
  const { user } = useAuth();
  const [apuracoes, setApuracoes] = useState<ApuracaoRow[]>([]);
  const [lojas, setLojas] = useState<LojaOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtroLoja, setFiltroLoja] = useState('');
  const [filtroStatus, setFiltroStatus] = useState('');
  const [busca, setBusca] = useState('');

  const isLoja = user?.perfil === 'loja';

  useEffect(() => {
    const load = async () => {
      const [apRes, lojasRes] = await Promise.all([
        supabase.from('apuracoes').select('*, lojas(nome)').order('data_apuracao', { ascending: false }),
        supabase.from('lojas').select('id, nome').eq('ativa', true).order('nome'),
      ]);
      setLojas(lojasRes.data || []);
      const mapped: ApuracaoRow[] = (apRes.data || []).map((a: any) => ({
        ...a,
        loja_nome: a.lojas?.nome || '—',
      }));
      setApuracoes(mapped);
      setLoading(false);
    };
    load();
  }, []);

  let lista = apuracoes;
  if (filtroLoja) lista = lista.filter(a => a.loja_id === filtroLoja);
  if (filtroStatus) lista = lista.filter(a => a.status === filtroStatus);
  if (busca) lista = lista.filter(a =>
    (a.loja_nome || '').toLowerCase().includes(busca.toLowerCase()) ||
    (a.sif || '').toLowerCase().includes(busca.toLowerCase()) ||
    (a.numero_apuracao || '').toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="page-header">
        <h1 className="page-title">Histórico de Apurações</h1>
        <p className="page-description">{lista.length} apurações encontradas</p>
      </div>

      <div className="bg-card rounded-lg border p-4 flex flex-wrap gap-3 items-end">
        <div className="flex-1 min-w-[200px]">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Buscar por loja ou SIF..." value={busca} onChange={e => setBusca(e.target.value)} className="pl-9" />
          </div>
        </div>
        {!isLoja && (
          <select value={filtroLoja} onChange={e => setFiltroLoja(e.target.value)} className="h-10 px-3 rounded-md border bg-background text-sm">
            <option value="">Todas as lojas</option>
            {lojas.map(l => <option key={l.id} value={l.id}>{l.nome}</option>)}
          </select>
        )}
        <select value={filtroStatus} onChange={e => setFiltroStatus(e.target.value)} className="h-10 px-3 rounded-md border bg-background text-sm">
          <option value="">Todos os status</option>
          <option value="rascunho">Rascunho</option>
          <option value="finalizada">Finalizada</option>
          <option value="revisada">Revisada</option>
        </select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      ) : (
        <div className="bg-card rounded-lg border overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="text-left p-3 font-medium text-muted-foreground">Nº</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Data</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Loja</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Tipo</th>
                <th className="text-right p-3 font-medium text-muted-foreground">Carcaça</th>
                <th className="text-right p-3 font-medium text-muted-foreground">Peso Inicial</th>
                <th className="text-right p-3 font-medium text-muted-foreground">Peso Final</th>
                <th className="text-right p-3 font-medium text-muted-foreground">Perda (kg)</th>
                <th className="text-right p-3 font-medium text-muted-foreground">Perda %</th>
                <th className="text-center p-3 font-medium text-muted-foreground">Status</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Responsável</th>
                <th className="text-center p-3 font-medium text-muted-foreground">Ações</th>
              </tr>
            </thead>
            <tbody>
              {lista.length === 0 ? (
                <tr><td colSpan={12} className="p-12 text-center text-muted-foreground">Nenhuma apuração encontrada</td></tr>
              ) : (
                lista.map(a => (
                  <tr key={a.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                    <td className="p-3 whitespace-nowrap font-mono text-xs font-semibold text-primary">{a.numero_apuracao || '—'}</td>
                    <td className="p-3 whitespace-nowrap">{new Date(a.data_apuracao).toLocaleDateString('pt-BR')}</td>
                    <td className="p-3 whitespace-nowrap">{a.loja_nome}</td>
                    <td className="p-3">
                      {a.tipo_apuracao === 'boi_no_osso' ? 'Boi no Osso' : 
                       a.tipo_apuracao === 'nota_10' ? 'Açougue Nota 10' : 
                       a.tipo_apuracao === 'embalada' ? 'Carne Embalada' : a.tipo_apuracao}
                    </td>
                    <td className="p-3 text-right">{Number(a.peso_carcaca).toFixed(2)}</td>
                    <td className="p-3 text-right">{Number(a.total_peso_inicial).toFixed(2)}</td>
                    <td className="p-3 text-right">{Number(a.total_peso_final).toFixed(2)}</td>
                    <td className="p-3 text-right font-medium">{Number(a.total_perda_kg).toFixed(2)}</td>
                    <td className="p-3 text-right font-medium">{Number(a.media_perda_percentual).toFixed(2)}%</td>
                    <td className="p-3 text-center"><StatusBadge status={a.status} /></td>
                    <td className="p-3 whitespace-nowrap">{a.responsavel}</td>
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Link to={`/apuracao/${a.id}`}>
                          <Button variant="ghost" size="icon" className="h-8 w-8"><Eye className="h-4 w-4" /></Button>
                        </Link>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><Copy className="h-4 w-4" /></Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
