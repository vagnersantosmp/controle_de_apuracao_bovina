import { ProcessedData } from './useDashboardData';
import { Button } from '@/components/ui/button';
import { Download, FileSpreadsheet } from 'lucide-react';
import { format } from 'date-fns';

interface Props {
  data: ProcessedData | null;
  loading: boolean;
}

export function DashboardTable({ data, loading }: Props) {
  if (loading || !data) return null;

  // Flatten apuracoes and validItems
  const rows = data.apuracoes.flatMap(ap => 
    ap.validItems.map((item: any) => ({
      loja: ap.lojas?.nome || '—',
      classe: ap.tipo_apuracao === 'boi_no_osso' ? 'Boi no Osso' : 
              ap.tipo_apuracao === 'nota_10' ? 'Açougue Nota 10' : 
              ap.tipo_apuracao === 'embalada' ? 'Carne Embalada' : ap.tipo_apuracao,
      corte: item.cortes?.descricao || '—',
      peso_inicial: Number(item.peso_inicial || 0),
      peso_final: Number(item.peso_final || 0),
      perda_kg: Number(item.perda_kg || 0),
      perda_pct: Number(item.perda_percentual || 0),
      data: new Date(ap.data_apuracao)
    }))
  ).sort((a, b) => b.data.getTime() - a.data.getTime()); // sort newest first

  const handleExport = () => {
    if (rows.length === 0) return;
    
    const headers = ['Loja', 'Classe de Apuração', 'Corte', 'Peso Inicial (kg)', 'Peso Final (kg)', 'Perda (kg)', 'Perda (%)', 'Data'];
    
    const csvContent = [
      headers.join(';'),
      ...rows.map(r => [
        `"${r.loja}"`,
        `"${r.classe}"`,
        `"${r.corte}"`,
        r.peso_inicial.toString().replace('.', ','),
        r.peso_final.toString().replace('.', ','),
        r.perda_kg.toString().replace('.', ','),
        r.perda_pct.toString().replace('.', ','),
        format(r.data, 'dd/MM/yyyy')
      ].join(';'))
    ].join('\n');

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Relatorio_Perdas_${format(new Date(), 'ddMMyyyy')}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-card rounded-xl border p-0 shadow-sm overflow-hidden flex flex-col">
      <div className="p-5 border-b flex items-center justify-between bg-muted/20">
        <div>
          <h3 className="text-base font-bold text-foreground">Apurações Recentes</h3>
          <p className="text-xs text-muted-foreground mt-1">Detalhamento por item apurado e cortado.</p>
        </div>
        <Button variant="outline" size="sm" onClick={handleExport} disabled={rows.length === 0} className="gap-2">
          <FileSpreadsheet className="w-4 h-4" />
          Exportar CSV
        </Button>
      </div>

      <div className="overflow-x-auto max-h-[500px]">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-muted/80 backdrop-blur-sm z-10 shadow-sm">
            <tr>
              <th className="text-left p-3 px-5 font-semibold text-muted-foreground whitespace-nowrap">Loja</th>
              <th className="text-left p-3 font-semibold text-muted-foreground whitespace-nowrap">Classe</th>
              <th className="text-left p-3 font-semibold text-muted-foreground whitespace-nowrap">Corte</th>
              <th className="text-right p-3 font-semibold text-muted-foreground whitespace-nowrap">Peso Inicial</th>
              <th className="text-right p-3 font-semibold text-muted-foreground whitespace-nowrap">Peso Final</th>
              <th className="text-right p-3 px-5 font-semibold text-muted-foreground whitespace-nowrap">Perda %</th>
              <th className="text-right p-3 font-semibold text-muted-foreground whitespace-nowrap">Data</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {rows.length === 0 ? (
              <tr><td colSpan={7} className="p-12 text-center text-muted-foreground">Nenhum dado encontrado para os filtros atuais.</td></tr>
            ) : (
              rows.map((r, i) => (
                <tr key={i} className="hover:bg-muted/30 transition-colors">
                  <td className="p-3 px-5 font-medium">{r.loja}</td>
                  <td className="p-3 text-muted-foreground">{r.classe}</td>
                  <td className="p-3">{r.corte}</td>
                  <td className="p-3 text-right text-muted-foreground">{r.peso_inicial.toFixed(1)} kg</td>
                  <td className="p-3 text-right text-muted-foreground">{r.peso_final.toFixed(1)} kg</td>
                  <td className="p-3 px-5 text-right font-medium">
                    <span className={r.perda_pct > 5 ? 'text-destructive' : ''}>
                      {r.perda_pct.toFixed(1)}%
                    </span>
                    <div className="w-16 h-1.5 bg-muted rounded-full ml-auto mt-1 overflow-hidden">
                      <div 
                        className={`h-full ${r.perda_pct > 5 ? 'bg-destructive' : 'bg-success'}`} 
                        style={{ width: `${Math.min(r.perda_pct, 100)}%` }} 
                      />
                    </div>
                  </td>
                  <td className="p-3 text-right text-muted-foreground text-xs whitespace-nowrap">{format(r.data, 'dd/MM/yyyy')}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
