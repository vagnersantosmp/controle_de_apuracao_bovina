import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Loader2, Database, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { addDays } from 'date-fns';

// BI Components
import { useDashboardData } from './dashboard/useDashboardData';
import { DashboardFilters } from './dashboard/DashboardFilters';
import { DashboardKPIs } from './dashboard/DashboardKPIs';
import { DashboardCharts } from './dashboard/DashboardCharts';
import { DashboardTable } from './dashboard/DashboardTable';

export default function DashboardPage() {
  const { user } = useAuth();
  
  // Options for filters
  const [lojasOptions, setLojasOptions] = useState<{ id: string; nome: string; codigo: string }[]>([]);
  const [cortesOptions, setCortesOptions] = useState<{ id: string; descricao: string; codigo?: string }[]>([]);
  const [optionsLoading, setOptionsLoading] = useState(true);
  const [seeding, setSeeding] = useState(false);
  const [cleaning, setCleaning] = useState(false);

  // Hook handles data fetching and calculations based on the filters
  const { data, loading, filters, setFilters, refetch } = useDashboardData(user);

  useEffect(() => {
    const loadOptions = async () => {
      const [lojasRes, cortesRes] = await Promise.all([
        supabase.from('lojas').select('id, codigo, nome').eq('ativa', true),
        supabase.from('cortes').select('id, descricao, codigo').eq('ativo', true).order('descricao')
      ]);
      setLojasOptions(lojasRes.data || []);
      setCortesOptions(cortesRes.data || []);
      setOptionsLoading(false);
    };
    loadOptions();
  }, []);

  // TEMP: Function to inject mock data
  const handleSeedData = async () => {
    if (!user) return;
    setSeeding(true);
    toast.info("Iniciando geração de testes...");

    try {
      const metodologias = ['boi_no_osso', 'nota_10', 'embalada'];
      let currentDate = new Date('2026-01-02T12:00:00Z');
      const endDate = new Date('2026-03-02T12:00:00Z');
      let apuracoesCriadas = 0;

      while (currentDate <= endDate) {
        const numStores = Math.floor(Math.random() * 3) + 3; // 3 to 5
        const selectedStores = [...lojasOptions].sort(() => 0.5 - Math.random()).slice(0, numStores);

        for (const loja of selectedStores) {
          const metodologia = metodologias[Math.floor(Math.random() * 3)];
          const availableCuts = cortesOptions; // for mock, let's use all or partial

          const numItems = Math.floor(Math.random() * 4) + 3; // 3 to 6
          const selectedCuts = [...availableCuts].sort(() => 0.5 - Math.random()).slice(0, numItems);

          let totalPI = 0;
          let totalPF = 0;
          let totalPerda = 0;

          // Compute item objects partially
          const tempItems = selectedCuts.map(corte => {
            const pesoIni = Math.random() * 30 + 15;
            const perdaPct = Math.random() * 0.12 + 0.02; // 2% to 14%
            const pesoFin = pesoIni * (1 - perdaPct);
            const perdaKg = pesoIni - pesoFin;
            
            totalPI += pesoIni;
            totalPF += pesoFin;
            totalPerda += perdaKg;

            return {
              corte_id: corte.id,
              corte_codigo: corte.codigo || '000',
              corte_descricao: corte.descricao || 'Corte Teste',
              peso_inicial: pesoIni,
              peso_final: pesoFin,
              perda_kg: perdaKg,
              perda_percentual: perdaPct * 100
            };
          });

          const mediaPerda = totalPI > 0 ? (totalPerda / totalPI) * 100 : 0;

          const { data: apuracao, error: apErr } = await supabase.from('apuracoes').insert({
            loja_id: loja.id,
            tipo_apuracao: metodologia,
            data_apuracao: currentDate.toISOString(),
            responsavel: 'Sistema Gerador (Teste)',
            status: 'finalizada',
            user_id: user.id, // we use the current user id so RLS passes!
            observacoes: 'TESTE_BI_DELETE_DEPOIS',
            peso_carcaca: Number((totalPI).toFixed(3)),
            total_peso_inicial: Number((totalPI).toFixed(3)),
            total_peso_final: Number((totalPF).toFixed(3)),
            total_perda_kg: Number((totalPerda).toFixed(3)),
            media_perda_percentual: Number((mediaPerda).toFixed(2))
          }).select().single();

          if (apErr) throw apErr;

          const itemsToInsert = tempItems.map(item => ({
            ...item,
            apuracao_id: apuracao.id
          }));

          const { error: itemsErr } = await supabase.from('itens_apuracao').insert(itemsToInsert);
          if (itemsErr) throw itemsErr;
          
          apuracoesCriadas++;
        }
        currentDate = addDays(currentDate, 7);
      }
      
      toast.success(`${apuracoesCriadas} apurações de teste injetadas!`);
      refetch(); // update dashboard

    } catch (e: any) {
      console.error(e);
      toast.error('Erro ao gerar testes: ' + e.message);
    } finally {
      setSeeding(false);
    }
  };

  const handleCleanData = async () => {
    try {
      setCleaning(true);
      const { error } = await supabase.from('apuracoes').delete().eq('observacoes', 'TESTE_BI_DELETE_DEPOIS');
      if (error) throw error;
      toast.success('Dados de teste apagados com sucesso!');
      refetch();
    } catch (e: any) {
      toast.error('Erro ao limpar testes: ' + e.message);
    } finally {
      setCleaning(false);
    }
  };

  if (!user) return null;
  const isGlobalAdmin = user.perfil === 'admin' || user.perfil === 'gestor' || user.perfil === 'prevencao';
  const lojaName = !isGlobalAdmin ? (lojasOptions.find(l => l.id === user.lojaId)?.nome || 'sua loja') : '';

  if (optionsLoading) {
    return <div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }

  return (
    <div className="space-y-6 animate-fade-in pb-10">
      
      {/* Header */}
      <div className="page-header flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="page-title text-2xl font-bold">Dashboard</h1>
          <p className="page-description text-muted-foreground">{!isGlobalAdmin ? `Visão de perdas da ${lojaName}` : 'Gestão e Análise de Perdas da Rede'}</p>
        </div>
        {(user.perfil === 'admin' || user.perfil === 'loja') && (
          <div className="flex gap-2">
            {isGlobalAdmin && (
              <>
                <Button onClick={handleCleanData} disabled={cleaning || seeding} variant="outline" className="shadow-sm text-destructive hover:text-destructive">
                  {cleaning ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
                  Limpar Dados Fake
                </Button>
                <Button onClick={handleSeedData} disabled={seeding || cleaning} variant="secondary" className="shadow-sm">
                  {seeding ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Database className="w-4 h-4 mr-2" />}
                  Gerar Dados Fake (2 Meses)
                </Button>
              </>
            )}
            <Link to="/nova-apuracao">
              <Button className="shadow-sm">Nova Apuração</Button>
            </Link>
          </div>
        )}
      </div>

      {/* Top Filter Bar */}
      <DashboardFilters 
        filters={filters}
        setFilters={setFilters}
        lojasOptions={lojasOptions}
        cortesOptions={cortesOptions}
        isGlobalAdmin={isGlobalAdmin}
      />

      {/* KPIs Line */}
      <DashboardKPIs data={data} loading={loading} />

      {/* Main Charts Area */}
      <DashboardCharts data={data} loading={loading} isGlobalAdmin={isGlobalAdmin} />

      {/* Detailed Data Table */}
      <DashboardTable data={data} loading={loading} />

    </div>
  );
}
