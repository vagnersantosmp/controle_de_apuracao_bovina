import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { startOfWeek, endOfWeek, startOfMonth, endOfMonth, subWeeks } from 'date-fns';
import { toast } from 'sonner';

export type FilterPeriod = 'last_week' | 'current_month' | 'custom';

export interface DashboardFilters {
  classe: string; // 'todas', 'boi_no_osso', 'nota_10', 'embalada'
  lojas: string[]; // empty means all
  cortes: string[]; // empty means all
  period: FilterPeriod;
  dateRange: { from: Date | undefined; to: Date | undefined };
}

export interface ProcessedData {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  apuracoes: any[];
  lojasCount: number;
  totalPI: number;
  totalPF: number;
  totalPerdaKg: number;
  mediaPerdaPercentual: number;
  lojaMaiorPerda: { nome: string; perda: number } | null;
  rankingLojas: { nome: string; perda: number }[];
  perdaPorClasse: { name: string; value: number }[];
  top10Cortes: { name: string; perda: number; perdaKg: number }[];
  evolucaoPerda: { mes: string; perda: number; apuracoes: number }[];
}

import { AppUser } from '@/contexts/AuthContext';

export function useDashboardData(user: AppUser | null | undefined) {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<ProcessedData | null>(null);
  
  const [filters, setFilters] = useState<DashboardFilters>({
    classe: 'todas',
    lojas: [],
    cortes: [],
    period: 'current_month',
    dateRange: { from: undefined, to: undefined }
  });

  const fetchBaseData = async () => {
    if (!user) return;

    // Guard: if custom period is selected but dates are incomplete, show empty state
    if (filters.period === 'custom' && (!filters.dateRange.from || !filters.dateRange.to)) {
      setData(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    
    try {
      // Build date constraints
      let startDateStr, endDateStr;
      
      const now = new Date();
      if (filters.period === 'current_month') {
        startDateStr = startOfMonth(now).toISOString();
        endDateStr = endOfMonth(now).toISOString();
      } else if (filters.period === 'last_week') {
        const lastWk = subWeeks(now, 1);
        startDateStr = startOfWeek(lastWk).toISOString();
        endDateStr = endOfWeek(lastWk).toISOString();
      } else if (filters.period === 'custom' && filters.dateRange.from && filters.dateRange.to) {
        startDateStr = filters.dateRange.from.toISOString();
        endDateStr = filters.dateRange.to.toISOString();
      }

      // Base query for Apuracoes
      let apQuery = supabase
        .from('apuracoes')
        .select(`
          *,
          lojas(nome, codigo),
          itens_apuracao (
            peso_inicial,
            peso_final,
            perda_kg,
            perda_percentual,
            corte_id,
            cortes ( descricao )
          )
        `)
        .neq('status', 'rascunho') // Assuming BI doesn't show drafts usually, or we can include them
        .order('data_apuracao', { ascending: false });

      if (startDateStr) apQuery = apQuery.gte('data_apuracao', startDateStr);
      if (endDateStr) apQuery = apQuery.lte('data_apuracao', endDateStr);
      
      if (filters.classe !== 'todas') {
        apQuery = apQuery.eq('tipo_apuracao', filters.classe);
      }

      // Role constraints
      if (user.perfil === 'loja' && user.lojaId) {
        apQuery = apQuery.eq('loja_id', user.lojaId);
      } else if (filters.lojas.length > 0) {
        apQuery = apQuery.in('loja_id', filters.lojas);
      }

      const { data: apuracoesRes, error } = await apQuery;
      if (error) throw error;

      // Process Data Memory-side for cuts filtering
      const validApuracoes = apuracoesRes || [];

      // If cuts are selected, we filter out items that don't match, and recalculate apuracao totals
      let totalPI = 0;
      let totalPF = 0;
      let totalPerdaKg = 0;

      const filteredApuracoes = validApuracoes.map(ap => {
        let validItems = ap.itens_apuracao || [];
        if (filters.cortes.length > 0) {
          validItems = validItems.filter((i: any) => filters.cortes.includes(i.corte_id));
        }

        const apPI = validItems.reduce((acc: number, item: any) => acc + Number(item.peso_inicial || 0), 0);
        const apPF = validItems.reduce((acc: number, item: any) => acc + Number(item.peso_final || 0), 0);
        const apPerda = apPI - apPF;
        const apPerdaPct = apPI > 0 ? (apPerda / apPI) * 100 : 0;

        totalPI += apPI;
        totalPF += apPF;
        totalPerdaKg += apPerda;

        return {
          ...ap,
          validItems,
          apPI,
          apPF,
          apPerda,
          apPerdaPct
        };
      }).filter(ap => ap.validItems.length > 0); // exclude apuracoes that have 0 items after cut filter

      const mediaPerdaPercentual = totalPI > 0 ? (totalPerdaKg / totalPI) * 100 : 0;

      // Calculate Lojas KPI
      const lojasSet = new Set(filteredApuracoes.map(ap => ap.loja_id));
      
      // Ranking por Loja
      const lojaMap = new Map();
      filteredApuracoes.forEach(ap => {
        const cod = ap.lojas?.codigo || 'Unknown';
        if (!lojaMap.has(cod)) lojaMap.set(cod, { nome: cod, pi: 0, perda: 0 });
        const entry = lojaMap.get(cod);
        entry.pi += ap.apPI;
        entry.perda += ap.apPerda;
      });
      const rankingLojas = Array.from(lojaMap.values()).map(l => ({
        nome: l.nome,
        perda: l.pi > 0 ? (l.perda / l.pi) * 100 : 0
      })).sort((a, b) => b.perda - a.perda);

      const lojaMaiorPerda = rankingLojas.length > 0 ? rankingLojas[0] : null;

      // Perda por Classe
      const classeMap = new Map();
      filteredApuracoes.forEach(ap => {
        const t = ap.tipo_apuracao;
        if (!classeMap.has(t)) classeMap.set(t, { pi: 0, perda: 0 });
        const entry = classeMap.get(t);
        entry.pi += ap.apPI;
        entry.perda += ap.apPerda;
      });
      const perdaPorClasse = Array.from(classeMap.entries()).map(([k, v]) => ({
        name: k === 'boi_no_osso' ? 'Boi no Osso' : k === 'nota_10' ? 'Açougue Nota 10' : 'Carne Embalada',
        value: v.pi > 0 ? (v.perda / v.pi) * 100 : 0,
        perdaKg: v.perda
      }));

      // Top 10 Cortes
      const corteMap = new Map();
      filteredApuracoes.forEach(ap => {
        ap.validItems.forEach((i: any) => {
          const cName = i.cortes?.descricao || 'Desconhecido';
          if (!corteMap.has(cName)) corteMap.set(cName, { pi: 0, perda: 0 });
          const entry = corteMap.get(cName);
          entry.pi += Number(i.peso_inicial || 0);
          entry.perda += Number(i.perda_kg || 0);
        });
      });
      const top10Cortes = Array.from(corteMap.entries()).map(([k, v]) => ({
        name: k,
        perda: v.pi > 0 ? (v.perda / v.pi) * 100 : 0,
        perdaKg: v.perda
      })).sort((a, b) => b.perda - a.perda).slice(0, 10);

      // Evolucao (Line chart)
      const weekMap = new Map();
      // simplified: group by week/month. For BI, let's group by week.
      filteredApuracoes.forEach(ap => {
        const d = new Date(ap.data_apuracao);
        const w = startOfWeek(d);
        const key = w.toISOString().split('T')[0];
        if (!weekMap.has(key)) weekMap.set(key, { pi: 0, perda: 0, count: 0 });
        const entry = weekMap.get(key);
        entry.pi += ap.apPI;
        entry.perda += ap.apPerda;
        entry.count += 1;
      });
      const evolucaoPerda = Array.from(weekMap.entries()).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => {
        const d = new Date(k);
        return {
          mes: `${d.getDate().toString().padStart(2,'0')}/${(d.getMonth() + 1).toString().padStart(2,'0')}`,
          perda: v.pi > 0 ? (v.perda / v.pi) * 100 : 0,
          apuracoes: v.count
        };
      });

      setData({
        apuracoes: filteredApuracoes,
        lojasCount: lojasSet.size,
        totalPI,
        totalPF,
        totalPerdaKg,
        mediaPerdaPercentual,
        lojaMaiorPerda,
        rankingLojas,
        perdaPorClasse,
        top10Cortes,
        evolucaoPerda
      });
      
    } catch (e: any) {
      console.error(e);
      toast.error('Erro ao buscar dados do dashboard');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBaseData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, filters]);

  return { data, loading, filters, setFilters, refetch: fetchBaseData };
}
