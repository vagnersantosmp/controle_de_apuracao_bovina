import { ProcessedData } from './useDashboardData';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, ResponsiveContainer, 
  LineChart, Line, CartesianGrid, PieChart, Pie, Cell, Legend, LabelList
} from 'recharts';

// Custom label renderer for donut bars — shows value% and name
const renderBarLabel = (props: any) => {
  const { x, y, width, height, value, index, data } = props;
  if (!data || width < 50) return null; // bar too small to show label
  const entry = data[index];
  if (!entry) return null;
  const label = `${entry.perda?.toFixed(1)}% · ${entry.perdaKg?.toFixed(1)}kg`;
  return (
    <text
      x={x + width - 6}
      y={y + height / 2}
      textAnchor="end"
      dominantBaseline="middle"
      fill="white"
      fontSize={10}
      fontWeight={600}
      style={{ textShadow: '0 1px 2px rgba(0,0,0,0.4)' }}
    >
      {label}
    </text>
  );
};

// Short names for donut labels
const CLASSE_SHORT: Record<string, string> = {
  'Boi no Osso': 'Boi',
  'Açougue Nota 10': 'Nota 10',
  'Carne Embalada': 'Embalada',
};

const renderDonutLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, name, value, perdaKg }: any) => {
  const RADIAN = Math.PI / 180;
  const radius = outerRadius + 30;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  const lx = cx + (outerRadius + 6) * Math.cos(-midAngle * RADIAN);
  const ly = cy + (outerRadius + 6) * Math.sin(-midAngle * RADIAN);
  const anchor = x > cx ? 'start' : 'end';
  const shortName = CLASSE_SHORT[name] || name;
  return (
    <g>
      <line x1={lx} y1={ly} x2={x} y2={y} stroke="hsl(var(--muted-foreground))" strokeWidth={1} />
      <text x={x} y={y - 6} textAnchor={anchor} dominantBaseline="central" fontSize={10} fontWeight={700} fill="hsl(var(--foreground))">
        {shortName} {value.toFixed(1)}%
      </text>
      <text x={x} y={y + 8} textAnchor={anchor} dominantBaseline="central" fontSize={9} fill="hsl(var(--muted-foreground))">
        {perdaKg != null ? `${perdaKg.toFixed(1)} kg` : ''}
      </text>
    </g>
  );
};

interface Props {
  data: ProcessedData | null;
  loading: boolean;
  isGlobalAdmin: boolean;
}

const COLORS = ['hsl(210, 100%, 50%)', 'hsl(160, 100%, 35%)', 'hsl(40, 100%, 50%)'];
const RANKING_COLORS = ['hsl(220, 80%, 40%)', 'hsl(160, 60%, 45%)', 'hsl(160, 60%, 60%)', 'hsl(160, 60%, 75%)', 'hsl(160, 60%, 85%)'];
const CORTES_COLOR = 'hsl(0, 70%, 55%)';

export function DashboardCharts({ data, loading, isGlobalAdmin }: Props) {
  if (loading || !data) return null;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Painel 1: Ranking de Lojas (Only makes sense if admin and multiple stores) */}
        {isGlobalAdmin ? (
          <div className="bg-card rounded-xl border p-5 shadow-sm col-span-1">
            <h3 className="text-sm font-bold text-foreground mb-4">Ranking de Perdas por Loja</h3>
            {data.rankingLojas.length === 0 ? (
              <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">Sem dados suficientes</div>
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={data.rankingLojas.slice(0,10)} layout="vertical" margin={{ left: 10, right: 30 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(210 18% 89%)" />
                  <XAxis type="number" tickFormatter={(v) => `${v}%`} tick={{ fontSize: 11 }} />
                  <YAxis dataKey="nome" type="category" width={50} tick={{ fontSize: 11 }} />
                  <RechartsTooltip 
                    formatter={(value: number) => [`${value.toFixed(2)}%`, 'Perda']}
                    contentStyle={{ borderRadius: 8, fontSize: '12px' }} 
                  />
                  <Bar dataKey="perda" radius={[0, 4, 4, 0]}>
                    {data.rankingLojas.slice(0,10).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={index === 0 ? RANKING_COLORS[0] : RANKING_COLORS[1]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        ) : null}

        {/* Painel 2: Donut Classe de Apuração */}
        <div className={`bg-card rounded-xl border p-5 shadow-sm ${isGlobalAdmin ? 'col-span-1' : 'col-span-1 lg:col-span-1'}`}>
          <h3 className="text-sm font-bold text-foreground mb-4">Perda por Classe de Apuração</h3>
          {data.perdaPorClasse.length === 0 || data.totalPI === 0 ? (
            <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">Sem dados suficientes</div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={data.perdaPorClasse}
                  cx="50%"
                  cy="46%"
                  innerRadius={58}
                  outerRadius={84}
                  paddingAngle={2}
                  dataKey="value"
                  label={renderDonutLabel}
                  labelLine={false}
                >
                  {data.perdaPorClasse.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <RechartsTooltip 
                  formatter={(value: number) => [`${value.toFixed(2)}%`, 'Perda Percentual']}
                  contentStyle={{ borderRadius: 8, fontSize: '12px' }} 
                />
                <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Painel 3: Top 10 Cortes */}
        <div className={`bg-card rounded-xl border p-5 shadow-sm ${isGlobalAdmin ? 'col-span-1' : 'col-span-1 lg:col-span-2'}`}>
          <h3 className="text-sm font-bold text-foreground mb-4">Top 10 Cortes com Maior Perda</h3>
          {data.top10Cortes.length === 0 ? (
            <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">Sem dados suficientes</div>
          ) : (
          <ResponsiveContainer width="100%" height={400}>
              <BarChart data={data.top10Cortes} layout="vertical" margin={{ left: 8, right: 40, top: 4, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(210 18% 89%)" />
                <XAxis type="number" tickFormatter={(v) => `${v}%`} tick={{ fontSize: 11 }} />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  width={155} 
                  tick={{ fontSize: 10, fill: 'hsl(var(--foreground))' }} 
                  interval={0}
                  tickFormatter={(value: string) => value.length > 22 ? value.slice(0, 22) + '…' : value}
                />
                <RechartsTooltip 
                  formatter={(value: number, name: string, props: any) => [`${value.toFixed(2)}% (${props.payload.perdaKg.toFixed(1)}kg)`, 'Perda']}
                  contentStyle={{ borderRadius: 8, fontSize: '12px' }} 
                />
                <Bar dataKey="perda" fill={CORTES_COLOR} radius={[0, 4, 4, 0]} barSize={24}>
                  {data.top10Cortes.map((entry, index) => (
                    <Cell key={`cell-${index}`} fillOpacity={1 - (index * 0.04)} />
                  ))}
                  <LabelList
                    content={(props: any) => renderBarLabel({ ...props, data: data.top10Cortes })}
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Painel Inferior: Evolução da Perda no Tempo */}
      <div className="bg-card rounded-xl border p-5 shadow-sm">
        <h3 className="text-sm font-bold text-foreground mb-4">Evolução da Perda no Período</h3>
        {data.evolucaoPerda.length === 0 ? (
          <div className="h-[220px] flex items-center justify-center text-muted-foreground text-sm">Sem dados suficientes</div>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={data.evolucaoPerda} margin={{ top: 20, right: 20, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(210 18% 89%)" />
              <XAxis dataKey="mes" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} dy={10} />
              <YAxis tickFormatter={(v) => `${v}%`} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
              <RechartsTooltip 
                formatter={(value: number) => [`${value.toFixed(2)}%`, 'Perda %']}
                labelFormatter={(l) => `Semana/Dia: ${l}`}
                contentStyle={{ borderRadius: 8, fontSize: '12px' }} 
              />
              <Line 
                type="monotone" 
                dataKey="perda" 
                stroke="hsl(220, 80%, 40%)" 
                strokeWidth={3} 
                dot={{ r: 4, fill: "white", strokeWidth: 2 }} 
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
